from flask import Flask, render_template, request
import stocks_data

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    date_str = ""
    stocks = None
    selected_stocks = []
    message = None
    symbols_selected = []

    if request.method == "POST":
        date_str = request.form.get("date")
        symbols_selected = request.form.getlist("symbols")

        # Load all stocks for the given date
        stocks = stocks_data.create_dictionary(date_str)
        if not stocks:
            message = f"No stock data found for {date_str}."
        elif symbols_selected:
            for sym in symbols_selected:
                stock = stocks_data.get_stock(stocks, sym)
                if stock:
                    selected_stocks.append(stock)
            if not selected_stocks:
                message = "None of the selected stock symbols were found."

    # For GET request or first page load, stocks=None → checkboxes won't appear until date is entered
    # But now we can pre-fill symbols if already submitted
    return render_template(
        "index.html",
        date_str=date_str,
        stocks=stocks,
        selected_stocks=selected_stocks,
        message=message,
        symbols_selected=symbols_selected
    )

if __name__ == "__main__":
    app.run(port=8080, debug=True)