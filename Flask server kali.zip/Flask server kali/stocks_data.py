import json
from datetime import datetime

def create_dictionary(date_str):
    dt = datetime.strptime(date_str, "%Y-%m-%d")
    try:
        with open(f"stock_data_{date_str}.json", "r") as fp:
            data = json.load(fp)
    except FileNotFoundError:
        return None

    stocks = {}
    for entry in data["data"]:
        raw_date = entry["date"]
        dt_entry = datetime.strptime(raw_date, "%Y-%m-%dT%H:%M:%S%z")
        formatted_date = dt_entry.strftime("%B %d, %Y")
        stocks[entry["symbol"]] = {
            "symbol": entry["symbol"],
            "date": formatted_date,
            "open": entry["open"],
            "high": entry["high"],
            "low": entry["low"],
            "close": entry["close"],
            "volume": entry["volume"]
        }
    return stocks

def get_stock(stocks, symbol):
    return stocks.get(symbol.upper(), None)
